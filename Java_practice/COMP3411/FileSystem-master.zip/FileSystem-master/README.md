# File system

This was completed as part of one of my university courses. All methods were fully implemented by me.  

  
I was instructed to design and implement a simple file system. By doing this, I was able to obtain a significant understanding of the file system internals. In this project the file system was created as an actual file in our computer system, named TFSDiskFile.
