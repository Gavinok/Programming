/*
 * @CreateTime: May 3, 2018 11:20 AM
 * @Author: Gavin Jaeger-Freeborn
 * @Contact: gavinfre@uvic.ca
 * @Last Modified By: Gavin Jaeger-Freeborn
 * @Last Modified Time: May 3, 2018 11:22 AM
 * @Student Number:T00611983
 * @ COMP 3411 Assignment 3
 * @Description: TFSDiskInputOutput is used to dirrectly access the TFSDiskFile
 * when unsing the TFSFileSystem and TFSShell 
 */

//package IO;
import java.io.*;
import java.util.*;

public class TFSDiskInputOutput
{
	//the limit to how large a new file can be
	private static final int BlockSixeLimit = 128;
	private static final int FileSizeLimit = 65535;
	private static RandomAccessFile GlobalRAF = null;
	private static File CurrentFile = null;
	public static int CurrentFileSize = 0;
	public static byte[] CurrentBlock = new byte[BlockSixeLimit];
	/* - Create a disk file of (size blocks). The disk file is a real file in your system, in which TFS is implemented. 
	- Return 0 if there is no error.  */
	
	public static int tfs_dio_create(byte[] name, int nlength, int size)
	{
		RandomAccessFile raf = null;
		if((FileSizeLimit >= size) && (nlength <= 15))
		{
			int totalsize = (size*BlockSixeLimit);
			try
			{					
					String convertedToString = new String(name);
					File NewFile = new File(convertedToString);
				 
				if(NewFile.exists()) // make sure it doesnt already exist
				{
					System.out.println("file already exists");
					return 1;
				}
				else
				{
					NewFile.createNewFile();
					raf = new RandomAccessFile(NewFile, "rw");
					raf.setLength(totalsize);
					System.out.println("TFSDiskFile created");
				}
			}
			// file error
			catch (Exception  e) 
			{  
   				System.out.println("Uh oh, got an IOException error!" + e.getMessage()); 
				return -1;
			}
			finally 
			{  
				// if the file opened okay, make sure we close it  
				if (raf != null) 
				{  
					try { raf.close(); }  
					catch (IOException ioe) { 
						System.out.println("failed to close file"); 
						return -1;
					} 
				} 
			} 

		}
		else
		{
			String convertedToString = new String(name);
			System.out.println("unsutable name of file size");
			return -1;
		}
		return 0;
	}	
	/* - Open a disk file 
	- Return 0 if there is no error. 	 */
	public static int tfs_dio_open(byte[] name, int nlength)
	{
		try
		{					
				String convertedToString = new String(name);
				CurrentFile = new File(convertedToString);
				
			if(CurrentFile.exists()) // make sure it doesnt already exist
			{
				GlobalRAF = new RandomAccessFile(CurrentFile, "rw");
				CurrentFileSize = (int)(GlobalRAF.length()/BlockSixeLimit);
				
			}
			else
			{
				System.out.println("file does not exist"); 
				return -1;
			}
		}
		// file error
		catch (Exception  e) 
		{  
			System.out.println("Uh oh, got an IOException error!" + e.getMessage()); 
			return -1;
		}
		return 0;
	}			
	/* 	- Get the total # of blocks of the disk file 
	- Return 0 if there is no error. 
	*/	
	public static int tfs_dio_get_size()
	{
		if(!(GlobalRAF == null))
		{
			try{
				CurrentFileSize = (int)(GlobalRAF.length()/BlockSixeLimit);
				
			}
			catch(IOException e)
			{
				System.out.println(" failed to determin size");
				return -1;
			}
			return (0);
		}
		else{
			System.out.println("no file is open");
			return -1;
		}
	}							
/* 	- Read a block from the disk file 
	- Return 0 if there is no error.  */
	public static int tfs_dio_read_block(int block_no, byte[] buf)
	{
			if(!(GlobalRAF == null))
			{
				try{
					if(((block_no*BlockSixeLimit)+ BlockSixeLimit)< GlobalRAF.length())
					{
						GlobalRAF.seek(block_no*BlockSixeLimit);
						GlobalRAF.readFully(buf, 0, BlockSixeLimit);
						CurrentBlock = buf;
					}
				}
				catch(IOException e)
				{
					System.out.println("Failed to read block");
					return -1;
				}
				catch(NullPointerException e)
				{
						System.out.println("Block is currently empty");
					return 1;
				}
				return 0;
			}
			else
			{
				System.out.println("no file is open");
				return -1;
			}
	
	}
/* 	- Write a block into the disk file 
	- Return 0 if there is no error.  */
	public static int tfs_dio_write_block(int block_no, byte[] buf)	
	{
		if(!(GlobalRAF == null))
		{
			try{
				GlobalRAF.seek(block_no*BlockSixeLimit);
				byte[] temp = new byte[BlockSixeLimit];
				temp = Arrays.copyOf(buf,BlockSixeLimit);
				GlobalRAF.write(temp);
			}
			catch(IOException e)
			{
				System.out.println("failed to read block");
				return -1;
			}
			catch(IndexOutOfBoundsException e)
			{
				System.out.println("this block number does ");
			}
			return 0;
		}
		else
		{
			System.out.println("no file is open");
			return -1;
		}
	}

/* 	- Close the disk file 
	- Return 0 if there is no error.  */
	public static int tfs_dio_close()		
	{
		if(!(GlobalRAF == null))
		{
			try{
				GlobalRAF.close();
				GlobalRAF = null;
				
			}
			catch(IOException e)
			{
				System.out.println("failed to read block");
				return -1;
			}
			return 0;
		}
		else
		{
			System.out.println("file is already closed");
			return -1;
		}
	}		
	public static void main(String[] args) {
		TFSDiskInputOutput fileIO = new TFSDiskInputOutput();

		//since the disk file would not be read able i am using a txt file
		String name = "hello.txt";

		//create the file (name is hello.txt, the total size is only 12 bytes)
		fileIO.tfs_dio_create(name.getBytes(), name.length(), 65535);

		//open the disk for i/o
		fileIO.tfs_dio_open(name.getBytes(), name.length());

		//check the size of the diskfile
		fileIO.tfs_dio_get_size();
		System.out.println(fileIO.CurrentFileSize);

		//try to read from the diskfile
		byte[] bufferBlock = new byte[BlockSixeLimit];
		fileIO.tfs_dio_read_block(0, bufferBlock);
		String BlockText = new String(bufferBlock);
		System.out.print(BlockText);
		
		//try to write to file
		String data = "inside of file";
		bufferBlock = data.getBytes();
		fileIO.tfs_dio_write_block(0, bufferBlock);

		//close disk file
		fileIO.tfs_dio_close();
	}			
}